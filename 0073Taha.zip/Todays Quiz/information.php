<?php


$name = $_POST['stdName'];
$Father = $_POST['stdFather'];
$contact = $_POST['stdContactAddress'];
$address = $_POST['stdAddress'];
$program = $_POST['fav_degree'];
$sports = $_POST['Sports'];
$travel = $_POST['Travel'];
$hostel = $_POST['Hostel'];

if($sports == "Sports")
{
    $sports = 1;
    $travel = 0;
    $hostel = 0;
}else if($travel == "Travel")
{
    $sports = 0;
    $travel = 1;
    $hostel = 0;
}elseif($hostel == "Hostel")
{
    $sports = 0;
    $travel = 0;
    $hostel = 1;
}else{
    $sports = 0;
    $travel = 0;
    $hostel = 0;
}

$conn = new mysqli("localhost","root","","register");
$q = "insert into std_info(stdName,stdFather,stdContactAddress,stdAddress,stdProgram,stdSports,stdTravel,stdHostel)values('".$name."','".$father."',".$contact.",".$address.",".$program.",".$sports.",".$travel.",".$hostel.")";
if($conn->query($q)==true){
    echo "Student Name is : ".$name."</br>";
    echo "Father Name is : ".$Father."</br>";
    echo "Student's contact address is : ".$contact."</br>";
    echo "Student's permanent address is : ".$address."</br>";
    echo "Student's enrolled program is : ".$program."</br>";
}else{
	echo $conn->error;
}
?>



