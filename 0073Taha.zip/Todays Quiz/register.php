<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
	<title>Register for Enrolment</title>
</head>
<body>
	<form method="POST" action="information.php">

		<input type="text" name="stdName" placeholder="Enter Student Name" ><br>

        <input type="text" name="stdFather" placeholder="Enter Father Name"><br>

		<input type="text" name="stdContactAddress" placeholder="Enter Contact Address"><br>

		<input type="text" name="stdAddress" placeholder="Enter Permanent Address"><br>

        <h3>Program Register For: </h3>

        <input type="radio" id="BBA" name="fav_degree" value="BBA">
        <label for="BBA">BBA</label><br>

        <input type="radio" id="MBA" name="fav_degree" value="MBA">
        <label for="MBA">MBA</label><br>

        <input type="radio" id="BSCS" name="fav_degree" value="BSCS">
        <label for="BSCS">BSCS</label><br>

        <input type="radio" id="MSCS" name="fav_degree" value="MSCS">
        <label for="MSCS">MSCS</label><br>

<h3>Additional Services if Requred: </h3>
        <input type="checkbox" id="Sports" name="Sports" value="Sports">
        <label for="vehicle1"> Sports Gymnasium</label><br>
        <input type="checkbox" id="Travel" name="Travel" value="Travel">
        <label for="vehicle2"> Travel with University Bus Service</label><br>
        <input type="checkbox" id="Hostel" name="Hostel" value="Hostel">
        <label for="vehicle3"> University Hostel Accomodation</label><br><br>

<input type="submit" value="Submit My Data">


	</form>

</body>
</html>